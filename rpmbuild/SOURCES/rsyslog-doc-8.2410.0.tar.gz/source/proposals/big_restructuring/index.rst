Rsyslog documentation
=====================

Below is the proposed documentation structure. It's initial content is the
current documentation available, just organized differently.

.. toctree::

    book/index
    cookbook/index
    reference/index
    contributing/index
    documentation_review.rst



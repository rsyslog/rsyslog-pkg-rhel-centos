Data Types
==========

RainerScript is a typeless language. That doesn't imply you don't need
to care about types. Of course, expressions like "A" + "B" will not
return a valid result, as you can't really add two letters (to
concatenate them, use the concatenation operator &).  However, all type
conversions are automatically done by the script interpreter when there
is need to do so.
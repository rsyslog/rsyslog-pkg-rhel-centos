$DynaFileCacheSize
------------------

This is an :doc:`omfile <../modules/omfile>` parameter. See there for details.

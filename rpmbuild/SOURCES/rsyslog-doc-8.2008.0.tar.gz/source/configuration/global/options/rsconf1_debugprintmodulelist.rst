$DebugPrintModuleList
---------------------

**Type:** global configuration parameter

**Default:** on

**Description:**

Specifies whether or not the module list should be written to the debug
log. Possible values: on/off. Default is on. Does not affect operation
if debugging is disabled.

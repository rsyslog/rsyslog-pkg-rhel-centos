#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# added 2021-11-05 by Theo Bertin, released under ASL 2.0

export USE_VALGRIND="YES"
. ${srcdir:-.}/rscript_faup_fragment.sh

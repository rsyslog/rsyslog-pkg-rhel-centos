#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# This wrapper retries the shared target-failure skeleton once more when TCP
# timing races trigger the known omfwd load-balancer flake. The second attempt
# keeps the same forced receiver-close scenario and bounded-loss oracle; it
# only avoids failing the suite on one unlucky reconnect timing window.
export srcdir="${srcdir:=.}"

export OMFWD_IOBUF_SIZE=1000 # triggers edge cases
skeleton="$srcdir/omfwd-lb-1target-retry-test_skeleton-TargetFail.sh"
max_attempts=2
attempt=1
result=1

while [ "$attempt" -le "$max_attempts" ]; do
    if [ "$attempt" -gt 1 ]; then
        echo "Retrying omfwd 1-byte target-failure test (attempt $attempt of $max_attempts) to mitigate TCP buffer timing races."
    fi

    if [ "$attempt" -lt "$max_attempts" ]; then
        TESTBENCH_SUPPRESS_FAIL_MARKER=YES bash "$skeleton"
    else
        bash "$skeleton"
    fi
    result=$?
    if [ "$result" -eq 0 ]; then
        if [ "$attempt" -gt 1 ]; then
            echo "omfwd 1-byte target-failure test passed on retry."
        fi
        exit 0
    fi

    attempt=$((attempt + 1))
done

echo "omfwd 1-byte target-failure test failed after $max_attempts attempts."
exit "$result"

#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# check canonical RainerScript -> YAML -> RainerScript round-trip.
#
# Part of the testbench for rsyslog.
#
# This file is part of rsyslog.
# Released under ASL 2.0
. ${srcdir:=.}/diag.sh init
require_plugin imtcp
modpath="../runtime/.libs:../plugins/imtcp/.libs:../.libs"
outlog="/tmp/${RSYSLOG_DYNNAME}.roundtrip.log"
portfile="${RSYSLOG_DYNNAME}.tcpflood_port"

cat > "${RSYSLOG_DYNNAME}.conf" <<RS_EOF
global(defaultNetstreamDriverCAFile="${srcdir}/tls-certs/ca.pem"
       defaultNetstreamDriverCertFile="${srcdir}/tls-certs/cert.pem"
       defaultNetstreamDriverKeyFile="${srcdir}/tls-certs/key.pem")

module(load="../plugins/imtcp/.libs/imtcp"
       StreamDriver.Name="gtls"
       StreamDriver.Mode="1"
       StreamDriver.AuthMode="x509/name"
       PermittedPeer=["rsyslog-client"])
input(type="imtcp" address="127.0.0.1" listenPortFileName="${portfile}" port="0")

template(name="outfmt" type="string" string="%msg:F,58:2%\n")

ruleset(name="main") {
  action(type="omfile" file="${outlog}" template="outfmt")
}
RS_EOF

../tools/rsyslogd -N1 -f "${RSYSLOG_DYNNAME}.conf" -F yaml -o "${RSYSLOG_DYNNAME}.roundtrip.yaml" -M"$modpath" || error_exit $?
../tools/rsyslogd -N1 -f "${RSYSLOG_DYNNAME}.roundtrip.yaml" -F rainerscript -o "${RSYSLOG_DYNNAME}.roundtrip.conf" -M"$modpath" || error_exit $?

cat > "${RSYSLOG_DYNNAME}.expected.yaml" <<YAML_EOF
version: 2

global:
  defaultNetstreamDriverCAFile: "${srcdir}/tls-certs/ca.pem"
  defaultNetstreamDriverCertFile: "${srcdir}/tls-certs/cert.pem"
  defaultNetstreamDriverKeyFile: "${srcdir}/tls-certs/key.pem"

modules:
  - load: "../plugins/imtcp/.libs/imtcp"
    PermittedPeer: ["rsyslog-client"]
    StreamDriver.AuthMode: "x509/name"
    StreamDriver.Mode: "1"
    StreamDriver.Name: "gtls"
inputs:
  - type: "imtcp"
    address: "127.0.0.1"
    listenPortFileName: "${portfile}"
    port: "0"
templates:
  - name: "outfmt"
    type: "string"
    string: "%msg:F,58:2%\n"
rulesets:
  - name: "main"
    actions:
      - type: "omfile"
        file: "${outlog}"
        template: "outfmt"
YAML_EOF
cmp_exact_file "${RSYSLOG_DYNNAME}.expected.yaml" "${RSYSLOG_DYNNAME}.roundtrip.yaml"

cat > "${RSYSLOG_DYNNAME}.expected.conf" <<RS_EOF
global(defaultNetstreamDriverCAFile="${srcdir}/tls-certs/ca.pem" defaultNetstreamDriverCertFile="${srcdir}/tls-certs/cert.pem" defaultNetstreamDriverKeyFile="${srcdir}/tls-certs/key.pem")

module(load="../plugins/imtcp/.libs/imtcp" PermittedPeer=["rsyslog-client"] StreamDriver.AuthMode="x509/name" StreamDriver.Mode="1" StreamDriver.Name="gtls")

input(type="imtcp" address="127.0.0.1" listenPortFileName="${portfile}" port="0")

template(name="outfmt" type="string" string="%msg:F,58:2%\n")

ruleset(name="main") {
  action(type="omfile" file="${outlog}" template="outfmt")
}

RS_EOF
cmp_exact_file "${RSYSLOG_DYNNAME}.expected.conf" "${RSYSLOG_DYNNAME}.roundtrip.conf"

../tools/rsyslogd -N1 -f "${RSYSLOG_DYNNAME}.roundtrip.conf" -M"$modpath" || error_exit $?

echo SUCCESS: RainerScript round-trip translation
exit_test

#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
export USE_VALGRIND="YES"
. ${srcdir:-.}/func-substring-invld-startpos.sh

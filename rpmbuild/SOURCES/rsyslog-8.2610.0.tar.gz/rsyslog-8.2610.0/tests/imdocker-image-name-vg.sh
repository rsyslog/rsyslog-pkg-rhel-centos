#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
export USE_VALGRIND="YES"
. "${srcdir:-$(dirname "$0")}/imdocker-image-name.sh"

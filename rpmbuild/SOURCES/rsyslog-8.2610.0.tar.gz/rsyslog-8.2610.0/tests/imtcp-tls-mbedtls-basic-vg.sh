#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
if [ "$(valgrind --version)" == "valgrind-3.11.0" ]; then
	printf 'This test does NOT work with valgrind-3.11.0 - valgrind always reports\n'
	printf 'a valgrind-internal bug. So we need to skip it.\n'
	exit 77
fi
export USE_VALGRIND="YES"
RSYSLOG_PRELOAD=$(find /usr -name libmbed\*.so | sed ':start;N;s/\n\//:\//;t start;P;D')
export RSYSLOG_PRELOAD
. ${srcdir:-.}/imtcp-tls-mbedtls-basic.sh

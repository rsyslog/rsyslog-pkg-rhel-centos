#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
export USE_VALGRIND="YES"
. ${srcdir:-.}/omfwd-tls-ossl-pkcs11-mtls-sigalgs-negative.sh

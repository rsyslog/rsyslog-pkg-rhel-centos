#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
# add 2019-04-04 by Philippe Duveau, released under ASL 2.0
. ${srcdir:=.}/diag.sh init
generate_conf
add_conf '
module(load="../contrib/improg/.libs/improg")
input(type="improg" tag="tag" ruleset="ruleset"
	  binary="'${srcdir:=.}'/improg-simul.sh -e '$RSYSLOG_DYNNAME'.stderr -n 1 -g"
	  confirmmessages="off" signalonclose="on" killunresponsive="on"
	 )
ruleset(name="ruleset") {
	action(type="omfile" file="'$RSYSLOG_OUT_LOG'")
}
'
startup
wait_content "program data" "$RSYSLOG_OUT_LOG"
shutdown_when_empty
wait_shutdown
content_check "program data"
if [ ! -e $RSYSLOG_DYNNAME.stderr ]; then
	echo $RSYSLOG_DYNNAME'.stderr missing'
	error_exit 1
fi
export EXPECTED='SIGTERM Received'
cmp_exact $RSYSLOG_DYNNAME.stderr
exit_test

#!/bin/bash
export LOWER_VAL='1'
export HIGHER_VAL='"b"'
. ${srcdir:-.}/rscript_compare-common.sh

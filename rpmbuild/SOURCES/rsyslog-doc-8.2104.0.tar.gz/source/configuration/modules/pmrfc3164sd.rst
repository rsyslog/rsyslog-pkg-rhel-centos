pmrfc3164sd: Parse RFC5424 structured data inside RFC3164 messages
==================================================================

A contributed module for supporting RFC5424 structured data inside 
RFC3164 messages (not supported by the rsyslog team)

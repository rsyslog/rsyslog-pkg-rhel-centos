$DebugPrintCFSyslineHandlerList
-------------------------------

**Type:** global configuration parameter

**Default:** on

**Description:**

Specifies whether or not the configuration file sysline handler list
should be written to the debug log. Possible values: on/off. Default is
on. Does not affect operation if debugging is disabled.


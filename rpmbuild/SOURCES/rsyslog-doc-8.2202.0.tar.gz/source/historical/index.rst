Historical Documents
--------------------
This part of the documentation set contains historical documents
which are still of interest or may be useful in some more exotic
environments.

.. toctree::
   :maxdepth: 2
   
   php_syslog_ng
   stunnel
   multi_ruleset_legacy_format_samples
   module_devel

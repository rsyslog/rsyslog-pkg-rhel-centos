The Cookbook
============

.. toctree::

    templates/index
    setup/index

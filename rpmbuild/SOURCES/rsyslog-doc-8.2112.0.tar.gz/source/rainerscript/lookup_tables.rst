Lookup Tables
=============

:doc:`Lookup tables <../configuration/lookup_tables>` are a powerful construct to obtain
"class" information based on message content (e.g. to build log file
names for different server types, departments or remote offices).


Log Sampling
============

Rsyslog supports various sampling mechanism.
User can perform sampling while collecting logs from client systems and forward it to server systems for aggregation and persistence.

Sampling strategies
-------------------

Rsyslog support following sampling strategies:-

 - :doc:`Random sampling<./random_sampling>`
 - :doc:`Hash based sampling<./hash_sampling>`

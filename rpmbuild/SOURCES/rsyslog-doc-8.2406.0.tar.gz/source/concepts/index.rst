Concepts
========

This chapter describes important rsyslog concepts and objects. Where
appropriate, it also refers to configurations settings to affect
the respective objects.

.. toctree::
   :maxdepth: 2
   
   queues
   janitor
   messageparser
   multi_ruleset
   netstrm_drvr
   
